﻿using System;
using System.Data;
using OS_19.DAL;

namespace OS_19.BLL
{
    internal class BLL_login
    {
        private string tipo_usuario;
        private string nome;
        private string id;

        public string logar(string usuario, string senha)
        {
            ConexaoBD bd = new ConexaoBD();
            string sql;
            DataTable dt;

            sql = string.Format("select * from usuario = '{0}' and senha = '{1}'", usuario, senha);
            dt = bd.ConsultarTabelas(sql);
            if(dt.Rows.Count > 0)
            {
                return "Usuario";
            }
            sql = String.Format("select * from tecnico where email = '{0}' and senha = '{1}'",usuario, senha);
            dt = bd.ConsultarTabelas(sql);
            if (dt.Rows.Count > 0)
            {
                return "Tecnico";
            }

            return "";
        }
    }
}
